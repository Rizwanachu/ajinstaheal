// Helper component for App.tsx if needed separately
export function ScrollToTop() {
  return null; 
}
