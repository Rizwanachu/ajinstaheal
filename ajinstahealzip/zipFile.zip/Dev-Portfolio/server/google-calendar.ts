import { google } from "googleapis";

// Google Calendar Service
// Completely FREE integration - no costs, ever
// Setup: User provides Google Service Account JSON credentials via env variable

interface CalendarEvent {
  title: string;
  description?: string;
  startTime: Date;
  endTime: Date;
  attendeeEmail?: string;
}

let calendar: calendar_v3.Calendar | null = null;

function initializeCalendar() {
  if (calendar) return calendar;

  try {
    const credentialsJson = process.env.GOOGLE_CALENDAR_CREDENTIALS;
    if (!credentialsJson) {
      console.warn("GOOGLE_CALENDAR_CREDENTIALS not configured");
      return null;
    }

    const credentials = JSON.parse(credentialsJson);
    const auth = new google.auth.GoogleAuth({
      credentials,
      scopes: ["https://www.googleapis.com/auth/calendar"],
    });

    calendar = google.calendar({
      version: "v3",
      auth,
    });

    return calendar;
  } catch (err) {
    console.error("Failed to initialize Google Calendar:", err);
    return null;
  }
}

export async function addEventToCalendar(event: CalendarEvent): Promise<boolean> {
  try {
    const cal = initializeCalendar();
    if (!cal) {
      console.log("Google Calendar not configured - skipping event creation");
      return false;
    }

    const calendarId = process.env.GOOGLE_CALENDAR_ID || "primary";

    const response = await cal.events.insert({
      calendarId,
      requestBody: {
        summary: event.title,
        description: event.description,
        start: {
          dateTime: event.startTime.toISOString(),
          timeZone: process.env.TIMEZONE || "UTC",
        },
        end: {
          dateTime: event.endTime.toISOString(),
          timeZone: process.env.TIMEZONE || "UTC",
        },
        attendees: event.attendeeEmail ? [{ email: event.attendeeEmail }] : undefined,
        notifications: {
          useDefault: false,
          overrides: [
            { type: "email", minutes: 24 * 60 }, // 24 hours before
            { type: "email", minutes: 60 }, // 1 hour before
          ],
        },
      },
    });

    console.log("Event added to Google Calendar:", response.data.id);
    return true;
  } catch (err) {
    console.error("Failed to add event to Google Calendar:", err);
    return false;
  }
}

export async function removeEventFromCalendar(eventId: string): Promise<boolean> {
  try {
    const cal = initializeCalendar();
    if (!cal) {
      console.log("Google Calendar not configured - skipping event deletion");
      return false;
    }

    const calendarId = process.env.GOOGLE_CALENDAR_ID || "primary";

    await cal.events.delete({
      calendarId,
      eventId,
    });

    console.log("Event removed from Google Calendar:", eventId);
    return true;
  } catch (err) {
    console.error("Failed to remove event from Google Calendar:", err);
    return false;
  }
}
